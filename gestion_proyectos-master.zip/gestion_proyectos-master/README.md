# Sistema de Gestión de Proyectos en PHP y MYSQL
<img src="Sistema%20de%20Gestión%20de%20Proyectos%20en%20PHP%20y%20MYSQL.png">

<!-- wp:paragraph -->
<p>Este Sistema de Gestión de Proyectos en PHP y MYSQL le permite al usuario administrador:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li>Listar, Ver, Editar y Eliminar los Proyectos a gestionar</li><li>Listar, Ver, Editar y Eliminar Empleados para los Proyectos</li><li>Listar, Ver, Editar y Eliminar Usuario de tipo Staff y Administrativo</li><li>Visualizar he Imprimir los reportes de tiempo trabajado por Proyecto</li><li>Visualizar he imprimir los reportes de tiempo trabajado por Empleado</li><li> Visualizar he imprimir los reportes de tiempo trabajado por Proyecto y Empleado</li><li> Listar, Ver, Editar y Eliminar Los tipos de trabajo asignados a los Empleados</li><li>Cambiar las configuraciones del Sistema,, nombre, nombre corto, logo del sistema y banner</li></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>El usuario de tipo Staff únicamente tiene la facultad de gestionar los reportes, los proyectos, los empleados y sus tipos de trabajo, no crea usuarios de tipo staff ni admin. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>El usuario final de perfil empleado, puede visualizar he imprimir los proyectos, sus reportes de tiempo trabajado, y el tiempo total asignado por Proyecto.</p>
<!-- /wp:paragraph -->

# Importante

La aplicación tiene un coste de 15 USD y para su implementación requieres la base de datos y es la que te proveo a cambio del importe.

# Enlace demo de la aplicación

https://demoscweb.com/proyectos/admin/login.php
Usuario: configuroweb
Clave: 1234abcd..

# Contacto

Me puedes contactar directamente a mi whats en el siguiente número
https://configuroweb.com/WhatsappMessenger

# El siguiente es el post relacionado con la aplicación

https://www.configuroweb.com/sistema-de-gestion-de-proyectos/
